﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Calculator
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            Class1.calculate("+");
        }

        private void btnSub_Click(object sender, EventArgs e)
        {
            Class1.calculate("-");
        }

        private void btnMul_Click(object sender, EventArgs e)
        {
            Class1.calculate("*");
        }

        private void btnDiv_Click(object sender, EventArgs e)
        {
            Class1.calculate("/");      
        }

        private void txtno1_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsDigit(e.KeyChar) && !(e.KeyChar == '.') && !char.IsControl(e.KeyChar))
            {
                e.Handled = true;
            }

            if (e.KeyChar == '.' && ((sender as TextBox).Text.IndexOf('.') > -1))
            {
                e.Handled = true;
            }
        }

        private void txtno2_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsDigit(e.KeyChar) && !(e.KeyChar == '.') && !char.IsControl(e.KeyChar))
            {
                e.Handled = true;
            }

            if (e.KeyChar == '.' && ((sender as TextBox).Text.IndexOf('.') > -1))
            {
                e.Handled = true;
            }
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            int a = Convert.ToInt32(MessageBox.Show("Do You Want To Exit?", "Calculator", MessageBoxButtons.YesNo, MessageBoxIcon.Question));
            if (a == 6)
            {
                Application.Exit();
            }
        }
    }
}
