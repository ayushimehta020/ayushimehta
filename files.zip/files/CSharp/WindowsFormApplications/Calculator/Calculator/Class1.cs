﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Calculator
{
    class Class1
    {
        public static void calculate(String sign)
        {
            if (txtno1.Text.Trim() != "" && txtno2.Text.Trim() != "")
            {
                double ans = 0;
                double n1 = Convert.ToDouble(txtno1.Text);
                double n2 = Convert.ToDouble(txtno2.Text);
                if (sign == "+")
                {
                    ans = n1 + n2;
                }
                else if (sign == "-")
                {
                    ans = n1 - n2;
                }
                else if (sign == "*")
                {
                    ans = n1 * n2;
                }
                else
                {
                    ans = n1 / n2;
                }
                lblAns.Text = "Answer is : " + Math.Round(ans, 2).ToString();
                txtno1.Text = "";
                txtno2.Text = "";
            }
        }
    }
}
