﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace WindowsFormsApplication2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            button1.Location = new Point(this.Width - 60, 0);
            button2.Location = new Point(this.Width - 120, 0);
            button3.Location = new Point(this.Width - 180, 0);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int a = Convert.ToInt32(MessageBox.Show("Do You Want To Exit", "APP1", MessageBoxButtons.YesNo, MessageBoxIcon.Question));
            if (a == 6)
            {
                Application.Exit();
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
            if (this.WindowState == FormWindowState.Maximized)
            {
                button1.Location = new Point(this.Width - 60, 0);
                button2.Location = new Point(this.Width - 120, 0);
                button3.Location = new Point(this.Width - 180, 0);
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (this.WindowState == FormWindowState.Maximized)
            {
                this.WindowState = FormWindowState.Normal;
                button1.Location = new Point(this.Width - 60, 0);
                button2.Location = new Point(this.Width - 120, 0);
                button3.Location = new Point(this.Width - 180, 0);
            }
            else
            {
                this.WindowState = FormWindowState.Maximized;
                button1.Location = new Point(this.Width - 60, 0);
                button2.Location = new Point(this.Width - 120, 0);
                button3.Location = new Point(this.Width - 180, 0);
            }
        }
    }
}