﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace DropDown1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (comboBox1.Items.Count >= 0)
            {
                if (comboBox1.Items.Count == 1)
                {
                    comboBox1.Items.Add("No Items!");
                }
                /* if (comboBox1.Items.Contains("No Items!"))
                {
                    comboBox1.Items.Remove("No Items!");
                } */
                comboBox2.Items.Add(comboBox1.SelectedItem);
                comboBox1.Items.Remove(comboBox1.SelectedItem);
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (comboBox2.Items.Count == 1)
            {
                comboBox2.Items.Add("No Items!");
            }
            comboBox1.Items.Add(comboBox2.SelectedItem);
            comboBox2.Items.Remove(comboBox2.SelectedItem);
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (comboBox1.Items.Count > 0)
            {
                if (comboBox1.Items.Contains("No Items!"))
                {
                    comboBox1.Items.Remove("No Items!");
                }
                for (int i = 0; i < comboBox1.Items.Count; i++)
                {
                    comboBox2.Items.Add(comboBox1.Items[i]);
                }
                comboBox1.Items.Clear();
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            if (comboBox2.Items.Count > 0)
            {
                if (comboBox2.Items.Contains("No Items!"))
                {
                    comboBox2.Items.Remove("No Items!");
                }
                for (int i = comboBox2.Items.Count - 1; i >= 0; i--)
                {
                    comboBox1.Items.Add(comboBox2.Items[i]);
                }
                comboBox2.Items.Clear();
            }
        }
    }
}
