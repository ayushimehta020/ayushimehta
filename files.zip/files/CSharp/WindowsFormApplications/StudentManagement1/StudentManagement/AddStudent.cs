﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.Sql;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace StudentManagement
{
    public partial class AddStudent : Form
    {
        string aadhar = "";
        string gender = "";
        string mobile = "";
        string city = "";
        string name = "";
        string course = "";

        public AddStudent()
        {
            InitializeComponent();
        }

        private void textBox1_KeyUp(object sender, KeyEventArgs e)
        {
            string sql = "select * from stud where aadhar_no='" + textBox1.Text + "'";
            SqlDataAdapter da = new SqlDataAdapter(sql, BSCIT.cn);
            DataTable dt = new DataTable();
            da.Fill(dt);

            if (textBox1.Text.Length == 12)
            {
                if (dt.Rows.Count > 0)
                {
                    textBox1.ForeColor = Color.Red;
                    aadhar = "n";
                }
                else
                {
                    textBox1.ForeColor = Color.Green;
                    aadhar = "y";
                }
            }
            else
            {
                textBox1.ForeColor = Color.Yellow;
            }
        }

        private void textBox1_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        private void textBox3_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        private void textBox3_KeyUp(object sender, KeyEventArgs e)
        {
            if (textBox3.Text.Length == 10)
            {
                textBox3.ForeColor = Color.Green;
                mobile = "y";
            }
            else
            {
                textBox3.ForeColor = Color.Red;
                mobile = "n";
            }
        }

        private void textBox5_TextChanged(object sender, EventArgs e)
        {
            if (textBox5.Text.Length == 0)
            {
                city = "n";
            }
            else
            {
                city = "y";
            }
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {
            if (textBox2.Text.Length == 0)
            {
                name = "n";
            }
            else
            {
                name = "y";
            }
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (comboBox1.SelectedIndex > -1)
            {
                course = "y";
            }
            else
            {
                course = "n";
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (aadhar == "y" && mobile == "y" && city == "y" && name == "y" && course == "y")
            {
                if (radioButton1.Checked == true)
                {
                    gender = "m";
                }
                else if (radioButton2.Checked == true)
                {
                    gender = "f";
                }
                else if (radioButton3.Checked == true)
                {
                    gender = "a";
                }
                string sql = "insert into stud values('" + textBox2.Text + "', '" + textBox3.Text + "', '" + dateTimePicker1.Text + "', '" + textBox1.Text + "', '" + textBox5.Text + "', '" + gender + "', '" + comboBox1.Text + "')";
                SqlDataAdapter da = new SqlDataAdapter(sql, BSCIT.cn);
                DataTable dt = new DataTable();
                da.Fill(dt);
                MessageBox.Show("Record inserted successfully!");
            }
            else
            {
                MessageBox.Show("Enter valid values!");
            }
        }

        protected override bool ProcessCmdKey(ref Message msg, Keys keyData)
        {
            if (keyData == Keys.Escape)
            {
                this.Close();
            }
            return true;
        }
    }
}
