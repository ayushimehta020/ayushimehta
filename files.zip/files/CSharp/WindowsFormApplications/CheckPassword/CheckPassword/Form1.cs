﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace CheckPassword
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void txtRePwd_KeyUp(object sender, KeyEventArgs e)
        {
            if (txtRePwd.Text == txtPwd.Text)
            {
                (sender as TextBox).ForeColor = Color.Green;
                btnSubmit.Enabled = true;
            }
            else
            {
                (sender as TextBox).ForeColor = Color.Red;
                btnSubmit.Enabled = false;
            }
        }

        private void btnSubmit_Click(object sender, EventArgs e)
        {
            txtPwd.Text = "";
            txtRePwd.Text = "";
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            btnSubmit.Enabled = false;
        }
    }
}
