﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace DropDown2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            comboBox1.Text = "Select Course";
            comboBox1.Items.Add("BSCIT");
            comboBox1.Items.Add("BCA");
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            comboBox2.Items.Clear();
            if (comboBox1.Text == "BSCIT")
            {
                comboBox2.Items.Add("SEM1");
                comboBox2.Items.Add("SEM2");
            }
            else if (comboBox1.Text == "BCA")
            {
                comboBox2.Items.Add("SEM3");
                comboBox2.Items.Add("SEM4");
            }
            else
            {
                MessageBox.Show("Please Select Course");
            }
        }
    }
}
