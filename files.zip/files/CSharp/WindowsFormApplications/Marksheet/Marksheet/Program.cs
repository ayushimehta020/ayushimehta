﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Marksheet
{
    class Program
    {
        static void Main(string[] args)
        {
            int m1, m2, m3, m4, total;
            float per;
            string grade, res;
            Console.WriteLine("Enter Marks 1 : ");
            m1 = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter Marks 2 : ");
            m2 = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter Marks 3 : ");
            m3 = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter Marks 4 : ");
            m4 = Convert.ToInt32(Console.ReadLine());
            if (m1 <= 100 && m2 <= 100 && m3 <= 100 && m4 <= 100)
            {
                total = m1 + m2 + m3 + m4;
                if (m1 >= 40 && m2 >= 40 && m3 >= 40 && m4 >= 40)
                {
                    per = total / 4;
                    res = "PASS";
                    if (per >= 70)
                    {
                        grade = "A";
                    }
                    else if (per >= 60)
                    {
                        grade = "B";
                    }
                    else if (per >= 50)
                    {
                        grade = "C";
                    }
                    else
                    {
                        grade = "D";
                    }
                }
                else
                {
                    per = 0;
                    res = "FAIL";
                    grade = "E";
                }
                Console.WriteLine("Total is : " + total);
                Console.WriteLine("Percentage is : " + per);
                Console.WriteLine("Result is : " + res);
                Console.WriteLine("Grade is : " + grade);
            }
            else
            {
                Console.WriteLine("Please Enter Marks Between 0 And 100");
            }
            Console.Read();
        }
    }
}
