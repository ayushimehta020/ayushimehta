﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Marksheet
{
    class Program
    {
        static void Main(string[] args)
        {
            int m1, m2, m3, m4, m5, m6, total;
            double per;
            string result;
            char grade;
            Console.BackgroundColor = ConsoleColor.White;
            Console.ForegroundColor = ConsoleColor.Black;
            Console.Clear();
            Console.Write("Enter Marks 1 : ");
            m1 = Convert.ToInt32(Console.ReadLine());
            Console.Write("Enter Marks 2 : ");
            m2 = Convert.ToInt32(Console.ReadLine());
            Console.Write("Enter Marks 3 : ");
            m3 = Convert.ToInt32(Console.ReadLine());
            Console.Write("Enter Marks 4 : ");
            m4 = Convert.ToInt32(Console.ReadLine());
            Console.Write("Enter Marks 5 : ");
            m5 = Convert.ToInt32(Console.ReadLine());
            Console.Write("Enter Marks 6 : ");
            m6 = Convert.ToInt32(Console.ReadLine());
            total = m1 + m2 + m3 + m4 + m5 + m6;
            if (m1 >= 40 && m2 >= 40 && m3 >= 40 && m4 >= 40 && m5 >= 40 && m6 >= 60)
            {
                per = total / 6.0;
                result = "PASS";
                if (per >= 90)
                {
                    grade = 'o';
                }
                else if (per >= 80)
                {
                    grade = 'A';
                }
                else if (per >= 70)
                {
                    grade = 'B';
                }
                else if (per >= 60)
                {
                    grade = 'C';
                }
                else if (per >= 50)
                {
                    grade = 'D';
                }
                else
                {
                    grade = 'E';
                }
            }
            else
            {
                per = total / 6.0;
                result = "FAIL";
                grade = 'F';
            }
            Console.WriteLine("Total is : " + total);
            Console.WriteLine("Percentage is : " + per);
            Console.WriteLine("Grade is : " + grade);
            Console.WriteLine("Result is : " + result);
            Console.Read();
        }
    }
}
