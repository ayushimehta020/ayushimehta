﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.Sql;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace StudentManagement
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string sql = "select * from login where username='" + textBox1.Text + "' and password='" + textBox2.Text + "'";
            SqlDataAdapter da = new SqlDataAdapter(sql, BSCIT.cn);
            DataTable dt = new DataTable();
            da.Fill(dt);
            if (dt.Rows.Count == 1)
            {
                string unm = dt.Rows[0][0].ToString();
                Home h = new Home(unm);
                h.Show();
                this.Hide();
            }
            else
            {
                MessageBox.Show("Invalid Username Or Password!");
            }
        }

        private void textBox2_Enter(object sender, EventArgs e)
        {
            textBox2.Text = "";
            textBox2.ForeColor = Color.Black;
            textBox2.UseSystemPasswordChar = true;
        }

        private void textBox2_Leave(object sender, EventArgs e)
        {
            if (textBox2.Text.Length == 0)
            {
                textBox2.ForeColor = Color.Gray;
                textBox2.Text = "Enter Password";
                textBox2.UseSystemPasswordChar = false;
                SelectNextControl(textBox2, true, true, false, true);
            }
        }
    }
}
