﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Sql;
using System.Data.SqlClient;
using System.Linq;
using System.Text;

namespace StudentManagement
{
    class BSCIT
    {
        public static SqlConnection cn = new SqlConnection(@"Data Source=.\SQLEXPRESS;AttachDbFilename=|DataDirectory|\BSCIT.mdf;Integrated Security=True;User Instance=True");
        // public static string unm = dt.Rows[0][0].ToString();
    }
}
