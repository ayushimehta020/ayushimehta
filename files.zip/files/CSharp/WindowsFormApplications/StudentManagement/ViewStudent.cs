﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.Sql;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace StudentManagement
{
    public partial class ViewStudent : Form
    {
        DataTable dt1 = new DataTable();
        public ViewStudent()
        {
            InitializeComponent();
        }

        protected override bool ProcessCmdKey(ref Message msg, Keys keyData)
        {
            if (keyData == Keys.Escape)
            {
                this.Hide();
            }
            return base.ProcessCmdKey(ref msg, keyData);
        }

        private void textBox1_KeyUp(object sender, KeyEventArgs e)
        {
            string aadhar = textBox1.Text;
            string sql = "select * from stud where aadhar_no like '" + aadhar + "%'";
            SqlDataAdapter da = new SqlDataAdapter(sql, BSCIT.cn);
            da.Fill(dt1);
            if (dt1.Rows.Count > 0)
            {
                listBox1.Visible = true;
                listBox1.Items.Clear();
                // dt1.Clear();
                for (int i = 0; i < dt1.Rows.Count; i++)
                {
                    listBox1.Items.Add(dt1.Rows[i][0]);
                }
                dt1.Clear();
            }
            else
            {
                textBox2.Text = "No Records Found!";
                listBox1.Visible = false;
            }
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            dataGridView1.DataSource = dt1;
        }
    }
}
