﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace StudentManagement
{
    public partial class Notepad : Form
    {
        string fileName = "";
        public Notepad()
        {
            InitializeComponent();
        }

        private void newToolStripMenuItem_Click(object sender, EventArgs e)
        {
            int a = Convert.ToInt32(MessageBox.Show("Do You Want To Save Your File?", "My Notepad", MessageBoxButtons.YesNo, MessageBoxIcon.Information));
            if (a == 6)
            {
                saveFile();
            }
            else
            {
                richTextBox1.Text = "";
            }
        }

        private void openToolStripMenuItem_Click(object sender, EventArgs e)
        {
            OpenFileDialog ofd = new OpenFileDialog();
            ofd.InitialDirectory = "C:\\Ayushi\\StudentManagement";
            ofd.Title = "My Notepad Open File";
            ofd.Filter = "Text files | *.txt";
            ofd.ShowDialog();
            if (ofd.FileName != "")
            {
                richTextBox1.LoadFile(ofd.FileName);
            }
        }

        private void saveToolStripMenuItem_Click(object sender, EventArgs e)
        {
            saveFile();
        }

        private void fontColorToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ColorDialog cd = new ColorDialog();
            cd.ShowDialog();
            richTextBox1.ForeColor = cd.Color;
        }

        private void fontToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FontDialog fd = new FontDialog();
            fd.ShowDialog();
            richTextBox1.Font = fd.Font;
        }

        private void saveFile()
        {
            SaveFileDialog sfd = new SaveFileDialog();
            sfd.DefaultExt = "txt";
            sfd.InitialDirectory = "C:\\Ayushi\\StudentManagement";
            sfd.Title = "My Notepad Save File";
            sfd.Filter = "Text files | *.txt";
            if (fileName == "")
            {
                sfd.ShowDialog();
                if (sfd.FileName != "")
                {
                    richTextBox1.SaveFile(sfd.FileName);
                }
                fileName = sfd.FileName;
            }
            else
            {
                richTextBox1.SaveFile(fileName);
            }
        }
    }
}
