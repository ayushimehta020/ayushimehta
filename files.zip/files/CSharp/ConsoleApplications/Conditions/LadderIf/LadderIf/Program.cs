﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace LadderIf
{
    class Program
    {
        static void Main(string[] args)
        {
            int n;
            Console.Write("Enter a number : ");
            n = Convert.ToInt32(Console.ReadLine());
            if (n > 0)
            {
                Console.WriteLine("Positive");
            }
            else if (n == 0)
            {
                Console.WriteLine("Zero");
            }
            else
            {
                Console.WriteLine("Negative");
            }
            Console.Read();
        }
    }
}
