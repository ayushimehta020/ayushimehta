﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace NestedIf
{
    class Program
    {
        static void Main(string[] args)
        {
            int age;
            Console.Write("Enter your age : ");
            age = Convert.ToInt32(Console.ReadLine());
            if (age > 0)
            {
                if (age >= 18)
                {
                    Console.WriteLine("Adult");
                }
                else
                {
                    Console.WriteLine("Teenage");
                }
            }
            else
            {
                Console.WriteLine("Landing on Earth Pending");
            }
            Console.Read();
        }
    }
}
