﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace IncomeTax
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Enter annual income : ");
            double income = Convert.ToInt32(Console.ReadLine());
            double incomeTax;
            if (income <= 500000)
            {
                incomeTax = income;
            }
            else if (income <= 1000000)
            {
                incomeTax = (income - 500000) * 0.1;
            }
            else if (income <= 2000000)
            {
                incomeTax = (income - 1000000) * 0.2 + 50000;
            }
            else
            {
                incomeTax = (income - 2000000) * 0.3 + 50000 + 200000;
            }
            Console.WriteLine("Annual income = Rs. " + income);
            Console.Write("Income tax = Rs. " + incomeTax);
            Console.Read();
        }
    }
}
