﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApplication4
{
    class Program
    {
        public double add(double a, double b)
        {
            return a + b;
        }
        public double sub(double a, double b)
        {
            return a - b;
        }
        public double mul(double a, double b)
        {
            return a * b;
        }
        public double div(double a, double b)
        {
            return a / b;
        }
        public double mod(double a, double b)
        {
            return a % b;
        }
        
        static void Main(string[] args)
        {
            int c = 1;
            double a = 0, b = 0, ans;
            Program program = new Program();
            while (c >= 1 && c <= 5)
            {
                Console.WriteLine();
                Console.WriteLine("Select from the below list : ");
                Console.WriteLine("1 - Addition");
                Console.WriteLine("2 - Subtraction");
                Console.WriteLine("3 - Multiplication");
                Console.WriteLine("4 - Division");
                Console.WriteLine("5 - Modulus");
                Console.Write("Enter your choice : ");
                c = Convert.ToInt32(Console.ReadLine());
                if (c >= 1 && c <= 5)
                {
                    Console.Write("Enter Number 1 : ");
                    a = Convert.ToDouble(Console.ReadLine());
                    Console.Write("Enter Number 2 : ");
                    b = Convert.ToDouble(Console.ReadLine());
                }
                else
                {
                    Console.WriteLine("Invalid Choice");
                }
                switch (c)
                {
                    case 1:
                        ans = program.add(a, b);
                        Console.WriteLine("Addition = " + ans);
                        break;
                    case 2:
                        ans = program.sub(a, b);
                        Console.WriteLine("Subtraction = " + ans);
                        break;
                    case 3:
                        ans = program.mul(a, b);
                        Console.WriteLine("Multiplication = " + ans);
                        break;
                    case 4:
                        ans = program.div(a, b);
                        Console.WriteLine("Division = " + ans);
                        break;
                    case 5:
                        ans = program.mod(a, b);
                        Console.WriteLine("Remainder = " + ans);
                        break;
                }
            }
            Console.Read();
        }
    }
}
