﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApplication1
{
    class Program
    {
        static void Main(string[] args)
        {
            int n1, n2, sum, sub, mul, div, mod;
            Console.BackgroundColor = ConsoleColor.White;
            Console.ForegroundColor = ConsoleColor.Black;
            Console.Clear();
            Console.Write("Enter Number 1 : ");
            n1 = Convert.ToInt32(Console.ReadLine());
            Console.Write("Enter Number 2 : ");
            n2 = Convert.ToInt32(Console.ReadLine());
            sum = n1 + n2;
            sub = n1 - n2;
            mul = n1 * n2;
            div = n1 / n2;
            mod = n1 % n2;
            Console.WriteLine("Sum = " + sum);
            Console.WriteLine("Sub = " + sub);
            Console.WriteLine("Mul = " + mul);
            Console.WriteLine("Div = " + div);
            Console.WriteLine("Mod = " + mod);
            Console.Read();
        }
    }
}
