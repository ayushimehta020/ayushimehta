﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApplication3
{
    class Program
    {
        static void Main(string[] args)
        {
            int i;
            Console.WriteLine("Enter 0 For White BG");
            Console.WriteLine("Enter 1 For Black BG");
            Console.WriteLine("Enter 2 For Green BG");
            Console.Write("Enter your choice : ");
            i = Convert.ToInt32(Console.ReadLine());
            switch (i)
            {
                case 0:
                    Console.BackgroundColor = ConsoleColor.White;
                    Console.Clear();
                    break;
                case 1:
                    Console.BackgroundColor = ConsoleColor.Black;
                    Console.Clear();
                    break;
                case 2:
                    Console.BackgroundColor = ConsoleColor.Green;
                    Console.Clear();
                    break;
                default:
                    Console.Write("Invalid Selection");
                    break;
            }
            Console.Read();
        }
    }
}
