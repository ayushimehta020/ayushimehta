﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Loop1
{
    class Program
    {
        static void Main(string[] args)
        {
            int old = 0, New = 0;
            Console.Write("Enter Any Number : ");
            int n = Convert.ToInt32(Console.ReadLine()); // 108
            Console.WriteLine("\nUsing for loop : ");
            for (int i = 1; i <= n; i++)
            {
                if (i <= 3)
                {
                    Console.Write(i + " ");
                    New = i;
                    old = i - 1;
                }
                else
                {
                    i = New * old;
                    if (i > n)
                    {
                        break;
                    }
                    Console.Write(i + " ");
                    old = New;
                    New = i;
                }
            }
            Console.WriteLine();
            Console.WriteLine("\nUsing while loop : ");
            int j = 1;
            while (j <= n)
            {
                if (j <= 3)
                {
                    Console.Write(j + " ");
                    New = j;
                    old = j - 1;
                }
                else
                {
                    j = New * old;
                    if (j > n)
                    {
                        break;
                    }
                    Console.Write(j + " ");
                    old = New;
                    New = j;
                }
                j++;
            }
            Console.WriteLine();
            Console.WriteLine("\nUsing do...while loop : ");
            j = 1;
            do
            {
                if (j <= 3)
                {
                    Console.Write(j + " ");
                    New = j;
                    old = j - 1;
                }
                else
                {
                    j = New * old;
                    if (j > n)
                    {
                        break;
                    }
                    Console.Write(j + " ");
                    old = New;
                    New = j;
                }
                j++;
            } while (j <= n);
            Console.Read();
        }
    }
}
