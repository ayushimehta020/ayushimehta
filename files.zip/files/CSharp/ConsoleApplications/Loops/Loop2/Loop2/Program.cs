﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Loop2
{
    class Program
    {
        static void Main(string[] args)
        {
            int New = 0, old = 0, k = 1;
            Console.Write("Enter Any Number : ");
            int n = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("\nUsing for loop : ");
            for (int i = 1; i <= n; i++)
            {
                for (int j = 1; j <= i; j++)
                {
                    if (k <= 3)
                    {
                        Console.Write(k + " ");
                        New = k;
                        old = k - 1;
                    }
                    else
                    {
                        k = New * old;
                        if (k > n)
                        {
                            break;
                        }
                        Console.Write(k + " ");
                        old = New;
                        New = k;
                    }
                    k++;
                }
                if (k > n)
                {
                    break;
                }
                Console.WriteLine();
            }
            Console.WriteLine("\nUsing while loop : ");
            int num1 = 1;
            k = 1;
            while (num1 <= n)
            {
                int j = 1;
                while (j <= num1)
                {
                    if (k <= 3)
                    {
                        Console.Write(k + " ");
                        New = k; // 2
                        old = k - 1; // 1
                    }
                    else
                    {
                        k = New * old;
                        if (k > n)
                        {
                            break;
                        }
                        Console.Write(k + " ");
                        old = New;
                        New = k;
                    }
                    j++;
                    k++;
                }
                if (k > n)
                {
                    break;
                }
                Console.WriteLine();
                num1++;
            }
            Console.WriteLine("\nUsing do...while loop : ");
            num1 = 1;
            k = 1;
            do
            {
                int j = 1;
                do
                {
                    if (k <= 3) // 2 <= 3
                    {
                        Console.Write(k + " "); // 1 2 3
                        New = k; // 3
                        old = k - 1; // 2
                    }
                    else
                    {
                        k = old * New; // 6
                        if (k > n) // 6 > 108
                        {
                            break;
                        }
                        Console.Write(k + " "); // 6
                        old = New; // 2
                        New = k; // 3
                    }
                    k++;
                    j++;
                } while (j <= num1); // 5 <= 4
                if (k > n)
                {
                    break;
                }
                Console.WriteLine();
                num1++; // 5
            } while (num1 <= n); // 5 <= 108
            Console.Read();
        }
    }
}
