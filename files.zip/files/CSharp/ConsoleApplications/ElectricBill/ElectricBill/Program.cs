﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ElectricBill
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Enter total unit consumption : ");
            int units = Convert.ToInt32(Console.ReadLine());
            double uc;
            if (units <= 50)
            {
                uc = units * 1.5;
            }
            else if (units <= 100)
            {
                uc = (units - 50) * 2.3 + 75;
            }
            else if (units <= 200)
            {
                uc = (units - 100) * 3 + 75 + 115;
            }
            else
            {
                uc = (units - 200) * 4 + 75 + 115 + 300;
            }
            int rent = 15;
            double tax = uc * 7.5 / 100;
            double net = uc + rent + tax;
            Console.WriteLine("Total units = " + units);
            Console.WriteLine("Unit charge = Rs. " + uc);
            Console.WriteLine("Rent = Rs. " + rent);
            Console.WriteLine("Tax = Rs. " + tax);
            Console.WriteLine("Net amount = Rs. " + net);
            Console.Read();
        }
    }
}
