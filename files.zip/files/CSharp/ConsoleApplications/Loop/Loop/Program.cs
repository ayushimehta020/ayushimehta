﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Loop
{
    class Program
    {
        static void Main(string[] args)
        {
            // Factorial of a number
            //int n, fact = 1;
            //Console.Write("Enter a number : ");
            //n = Convert.ToInt32(Console.ReadLine());
            //for (int i = n; i >= 1; i--)
            //{
            //    fact = fact * i;
            //}
            //Console.Write("Factorial = " + fact);
            //Console.Read();

            char color;
            Console.WriteLine("Color list : ");
            Console.WriteLine("R - Red");
            Console.WriteLine("G - Green");
            Console.WriteLine("B - Blue");
            Console.WriteLine("Y - Yellow");
            Console.WriteLine("M - Magenta");
            Console.WriteLine("g - Gray");
            Console.Write("Enter name of the color from the above list : ");
            color = Convert.ToChar(Console.ReadLine());
            switch(color)
            {
                case 'R':
                    Console.BackgroundColor = ConsoleColor.Red;
                    Console.ForegroundColor = ConsoleColor.White;
                    break;
                case 'G':
                    Console.BackgroundColor = ConsoleColor.Green;
                    Console.ForegroundColor = ConsoleColor.White;
                    break;
                case 'B':
                    Console.BackgroundColor = ConsoleColor.Blue;
                    Console.ForegroundColor = ConsoleColor.White;
                    break;
                case 'Y':
                    Console.ForegroundColor = ConsoleColor.Yellow;
                    break;
                case 'M':
                    Console.ForegroundColor = ConsoleColor.Magenta;
                    Console.BackgroundColor = ConsoleColor.White;
                    break;
                case 'g':
                    Console.ForegroundColor = ConsoleColor.Gray;
                    Console.BackgroundColor = ConsoleColor.White;
                    break;
                default:
                    Console.Write("Invalid Color Code");
                    break;
            }
    }
}
