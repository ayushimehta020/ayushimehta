class First
{
	public static void main(String args[])
	{
		int a = 100;
		float b = 10.2f;
		double c = 5.89;
		short d = 34;
		long e = 349;
		char f = 'A';
		String g = "Ayushi";
		boolean h = true;
		byte i = 32;
		
		System.out.println("a = " + a);
		System.out.println("b = " + b);
		System.out.println("c = " + c);
		System.out.println("d = " + d);
		System.out.println("e = " + e);
		System.out.println("f = " + f);
		System.out.println("g = " + g);
		System.out.println("h = " + h);
		System.out.println("i = " + i);
	}
}