import java.util.Scanner;

class Calc
{
	public static void main(String[] args)
	{
		Scanner in = new Scanner(System.in);
		int c = 1, n1 = 0, n2 = 0, ans = 0;
		while (c >= 1 && c <= 5)
		{
			System.out.println("Enter your choice : ");
			System.out.println("1 = Addition");
			System.out.println("2 = Subtraction");
			System.out.println("3 = Multiplication");
			System.out.println("4 = Division");
			System.out.println("5 = Modulus");
			System.out.println("Enter your choice : ");
			c = in.nextInt();
			if (c >= 1 && c <= 5)
			{
				System.out.println("Enter first number : ");
				n1 = in.nextInt();
				System.out.println("Enter second number : ");
				n2 = in.nextInt();
			}
			switch (c)
			{
				case 1:
					ans = n1 + n2;
					System.out.println("Addition is : " + ans);
					break;
				case 2:
					ans = n1 - n2;
					System.out.println("Subtraction is : " + ans);
					break;
				case 3:
					ans = n1 * n2;
					System.out.println("Multiplication is : " + ans);
					break;
				case 4:
					ans = n1 / n2;
					System.out.println("Division is : " + ans);
					break;
				case 5:
					ans = n1 % n2;
					System.out.println("Remainder is : " + ans);
					break;
				default:
					System.out.println("Invalid Selection");
			}
		}
	}
}