import java.util.Scanner;

class Marksheet
{
	public static void main(String[] args)
	{
		Scanner in = new Scanner(System.in);
		int m1, m2, m3, m4, m5, m6, total;
		double per;
		char grade;
		String result;
		System.out.println("Enter marks of 6 subjects : ");
		m1 = in.nextInt();
		m2 = in.nextInt();
		m3 = in.nextInt();
		m4 = in.nextInt();
		m5 = in.nextInt();
		m6 = in.nextInt();
		total = m1 + m2 + m3 + m4 + m5 + m6;
		if (m1 >= 40 && m2 >= 40 && m3 >= 40 && m4 >= 40 && m5 >= 40 && m6 >= 40)
		{
			per = total / 6.0;
			result = "PASS";
			if (per >= 90)
			{
				grade = 'o';
			}
			else if (per >= 80)
			{
				grade = 'A';
			}
			else if (per >= 70)
			{
				grade = 'B';
			}
			else if (per >= 60)
			{
				grade = 'C';
			}
			else if (per >= 50)
			{
				grade = 'D';
			}
			else
			{
				grade = 'E';
			}
		}
		else 
		{
			per = total / 6.0;
			result = "FAIL";
			grade = 'F';
		}
		System.out.println("Total = " + total);
		System.out.println("Percentage = " + per);
		System.out.println("Grade = " + grade);
		System.out.println("Result = " + result);
	}
}