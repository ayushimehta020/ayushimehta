/*
	Input average marks of a student. Write a program that print grade.
	Average Marks	Grade
	>= 70			Distinction
	>=60 and <=70	First
	>=50 and <=60	Second
	>=40 and <=50	Pass
	<= 40			Try again
*/

import java.util.*;

class SwitchGrade
{
	public static void main(String args[])
	{
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter average marks of a student : ");
		int avg = sc.nextInt();
		int c = avg / 10;
		switch (c)
		{
			case 10:
			case 9:
				System.out.println("Distinction");
				break;
			case 8:
			case 7:
				System.out.println("First");
				break;
			case 6:
			case 5:
				System.out.println("Second");
				break;
			case 4:
				System.out.println("Pass");
				break;
			default:
				System.out.println("Try again");
				break;
		}
	}
}