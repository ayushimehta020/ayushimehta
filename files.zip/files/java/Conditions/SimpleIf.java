// Input marks of three subjects. Write a program that print result(PASS, FAIL or ATKT).

class SimpleIf
{
	public static void main(String args[])
	{
		int m1 = Integer.parseInt(args[0]);
		int m2 = Integer.parseInt(args[1]);
		int m3 = Integer.parseInt(args[2]);
		
		if (m1 >= 40 && m2 >= 40 && m3 >= 40)
		{
			System.out.println("PASS");
		}
		if ((m1 >= 40 && m2 >= 40 && m3 < 40) || (m1 >= 40 && m2 < 40 && m3 >= 40) || (m1 < 40 && m2 >= 40 && m3 >= 40))
		{
			System.out.println("ATKT");
		}
		if ((m1 >= 40 && m2 < 40 && m3 < 40) || (m1 < 40 && m2 < 40 && m3 >= 40) || (m1 < 40 && m2 >= 40 && m3 < 40) || (m1 < 40 && m2 < 40 && m3 < 40))
		{
			System.out.println("FAIL");
		}
	}
}