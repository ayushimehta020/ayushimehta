// Input sides of the triangle. Write a program that check whether the triangle is equilateral triangle or isosceles triangle or scalene triangle.

import java.util.*;

class TriangleTypes
{
	public static void main(String args[])
	{
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter three sides of the triangle : ");
		int a = sc.nextInt();
		int b = sc.nextInt();
		int c = sc.nextInt();
		if (a == b && b == c && c == a)
		{
			System.out.println("The given sides are of equilateral triangle.");
		}
		else if (a != b && b != c && c != a)
		{
			System.out.println("The given sides are of scalene triangle.");
		}
		else
		{
			System.out.println("The given sides are of isosceles triangle.");
		}
	}
}