// Inout three values. Write a program that check whether the values form a triangle.

import java.util.*;

class ValidTriangle
{
	public static void main(String args[])
	{
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter three values : ");
		int a = sc.nextInt();
		int b = sc.nextInt();
		int c = sc.nextInt();
		if (a > b + c || b > a + c || c > a + b)
		{
			System.out.println("The given sides can form a triangle");
		}
		else
		{
			System.out.println("The given sides cannot form a triangle");
		}
	}
}