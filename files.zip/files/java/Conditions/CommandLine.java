// Sum of two numbers using CLI

class CommandLine
{
	public static void main(String args[])
	{
		int a = Integer.parseInt(args[0]);
		int b = Integer.parseInt(args[1]);
		System.out.println("a = " + a);
		System.out.println("b = " + b);
		System.out.println("Sum = " + (a + b));
		System.out.println("Dif = " + (a - b));
		System.out.println("Mul = " + (a * b));
		System.out.println("Div = " + (a / b));
		System.out.println("Mod = " + (a % b));
	}
}