/*
	Input annual income. Write a program that print income tax.
	
	Annual Income				Tax
	<= 500000					Nil
	>=500000 and <=1000000		10%
	>=1000000 and <=2000000		20%
	>= 2000000					30%
*/

import java.util.*;

class IncomeTax
{
	public static void main(String args[])
	{
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter annual income : ");
		int income = sc.nextInt();
		double incomeTax;
		if (income <= 500000)
		{
			incomeTax = income;
		}
		else if (income <= 1000000) // 10%
		{
			incomeTax = (income - 500000) * 0.1;
		}
		else if (income <= 2000000) // 20%
		{
			incomeTax = (income - 1000000) * 0.2 + 50000;
		}
		else // 30%
		{
			incomeTax = (income - 2000000) * 0.3 + 50000 + 200000;
		}
		System.out.println("Annual income = " + income);
		System.out.println("Income tax = " + incomeTax);
	}
}