/*
	Input total units. Write a program that print electric bill.
	
	Unit		Rs./Amount
	First 50	Rs. 1.5
	Next 50		Rs. 2.3
	Next 100	Rs. 3
	Above		Rs. 4
	
	Rent		Rs. 15
	Tax			7.5%
	Net Amount  Unit charge + Rent + Tax
*/

import java.util.*;

class ElectricBill
{
	public static void main(String args[])
	{
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter total units consumption : ");
		int units = sc.nextInt();
		double uc;
		if (units <= 50)
		{
			uc = units * 1.5;
		}
		else if (units <= 100)
		{
			uc = (units - 50) * 2.3 + 75;
		}
		else if (units <= 200)
		{
			uc = (units - 100) * 3 + 75 + 115;
		}
		else
		{
			uc = (units - 200) * 4 + 75 + 115 + 300;
		}
		int rent = 15;
		double tax = uc * 7.5 / 100;
		double net = uc + rent + tax;
		System.out.println("Total units = " + units);
		System.out.println("Unit charge = Rs. " + uc);
		System.out.println("Rent = Rs. " + rent);
		System.out.println("Tax = Rs. " + tax);
		System.out.println("Net amount = Rs. " + net);
	}
}