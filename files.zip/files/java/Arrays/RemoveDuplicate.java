// Input value in an array. Remove the duplicate values.

import java.util.*;

class RemoveDuplicate
{
	public static void main(String args[])
	{
		Scanner sc = new Scanner(System.in);
		int[] a = new int[5];
		for (int i = 0; i < a.length; i++)
		{
			System.out.print("Enter a[" + i + "] : ");
			a[i] = sc.nextInt();
		}
	}
}