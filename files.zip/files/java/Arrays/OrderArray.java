// Print array in original array, ascending order and descending order.

import java.util.*;

class OrderArray
{
	public static void main(String args[])
	{
		int[] a = new int[10];
		Scanner sc = new Scanner(System.in);
		for (int i = 0; i < a.length; i++)
		{
			System.out.print("Enter a[" + i + "] : ");
			a[i] = sc.nextInt();
		}
		System.out.println("\nOriginal Array");
		for (int i = 0; i < a.length; i++)
		{
			System.out.print(a[i] + " ");
		}
		System.out.println("\n\nArray in ascending order : ");
		Arrays.sort(a);
		for (int i = 0; i < a.length; i++)
		{
			System.out.print(a[i] + " ");
		}
		System.out.println("\n\nArray in descending order : ");
		for (int i = a.length - 1; i >= 0; i--)
		{
			System.out.print(a[i] + " ");
		}
	}
}