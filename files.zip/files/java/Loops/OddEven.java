// Inout values until input is not equal 0. Print sum of odd and even numbers.

import java.util.*;

class OddEven
{
	public static void main(String args[])
	{
		int n = 1, even = 0, odd = 0;
		Scanner sc = new Scanner(System.in);
		while (n != 0)
		{
			System.out.print("Enter n(0 to terminate) : ");
			n = sc.nextInt();
			if (n == 0)
				break;
			if (n % 2 == 0)
				even += n;
			if (n % 2 != 0)
				odd += n;
		}
		System.out.println("\nSum of even numbers : " + even);
		System.out.println("Sum of odd numbers : " + odd);
	}
}