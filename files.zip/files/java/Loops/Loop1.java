/*
	1, 2, 3, 4, 5, .....
	10, 9, 8, 7, 6, .....
	n + 1
	1, 4, 7, 10, .....
	1, 2, 4, 7, 11, .....
	1, 2, 5, 10, 17, .....
	1, 2, 4, 8, 16, .....
	1, 2, 6, 24, 120, .....
	0, 1, 1, 2, 3, 5, .....
	101, 101, 102, 103, 105, .....
*/

class Loop1
{
	public static void main(String args[])
	{
		int n, i, a, b;
		n = Integer.parseInt(args[0]);
		
		for (i = 1; i <= n; i++)
		{
			System.out.print(i + " ");
		}
		System.out.println();
		
		for (i = n; i >= 1; i--)
		{
			System.out.print(i + " ");
		}
		System.out.println();
		
		for (i = 1; i <= n; i++);
			System.out.print(i + " ");
		System.out.println();
		
		a = 1;
		for (i = 1; i <= n; i++)
		{
			System.out.print(a + " ");
			a = a + 3;
		}
		System.out.println();
		
		a = 1;
		b = 1;
		for (i = 1; i <= n; i++)
		{
			System.out.print(a + " ");
			a = a + b;
			b = b + 1;
		}
		System.out.println();
		
		a = 1;
		b = 1;
		for (i = 1; i <= n; i++)
		{
			System.out.print(a + " ");
			a = a + b;
			b = b + 2;
		}
		System.out.println();
		
		a = 1;
		for (i = 1; i <= n; i++)
		{
			System.out.print(a + " ");
			a = a * 2;
		}
		System.out.println();
		
		a = 1;
		for (i = 1; i <= n; i++)
		{
			a = a * i;
			System.out.print(a + " ");
		}
		System.out.println();
		
		int s = 0;
		a = -1;
		b = 1;
		for (i = 1; i <= n; i++)
		{
			s = a + b;
			System.out.print(s + " ");
			a = b;
			b = s;
		}
		System.out.println();
		
		s = 0;
		a = 1;
		b = 0;
		for (i = 1; i <= n; i++)
		{
			s = a + b;
			System.out.print((s + 100) + " ");
			a = b;
			b = s;
		}
		System.out.println();
	}
}