import java.util.*;

class CheckNumber
{
	public static void main(String args[])
	{
		int i;
		int n = Integer.parseInt(args[0]);
		for (i = 2; i < n; i++)
		{
			if (n % i == 0)
				break;
		}
		if (n == i)
			System.out.println(n + " is Prime");
		else
			System.out.println(n + " is Not Prime");
	}
}