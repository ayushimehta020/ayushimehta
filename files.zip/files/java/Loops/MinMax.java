// Input numbers until input is not equal -999. Print minimum and maximum values.

import java.util.*;

class MinMax
{
	public static void main(String args[])
	{
		int n, min, max;
		Scanner sc = new Scanner(System.in);
		System.out.print("Enter n(-999 to terminate) : ");
		n = sc.nextInt();
		min = n;
		max = n;
		while (n != -999)
		{
			System.out.print("Enter n : ");
			n = sc.nextInt();
			if (n == -999)
				break;
			if (n < min)
				min = n;
			if (n > max)
				max = n;
		}
		System.out.println("\nMinimum Value = " + min);
		System.out.println("Maximum Value = " + max);
	}
}