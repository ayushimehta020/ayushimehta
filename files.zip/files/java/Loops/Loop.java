import java.util.*;

class Loop
{
	public static void main(String args[])
	{
		Scanner sc = new Scanner(System.in);
		int New = 0, old = 0, k = 1;
		System.out.print("Enter a number : ");
		int n = sc.nextInt();
		for (int i = 1; i <= n; i++)
		{
			for (int j = 1; j <= i; j++)
			{
				if (k <= 3)
				{
					System.out.print(k + " ");
					New = k;
					old = k - 1;
				}
				else
				{
					k = New * old;
					if (k > n)
					{
						break;
					}
					System.out.print(k + " ");
					old = New;
					New = k;
				}
				k++;
			}
			if (k > n)
			{
				break;
			}
			System.out.println();
		}
		
		System.out.println();
		k = 1;
		int i = 1;
		while (i <= n)
		{
			int j = 1;
			while (j <= i)
			{
				if (k <= 3)
				{
					System.out.print(k + " ");
					New = k;
					old = k - 1;
				}
				else
				{
					k = New * old;
					if (k > n)
					{
						break;
					}
					System.out.print(k + " ");
					old = New;
					New = k;
				}
				j++;
				k++;
			}
			if (k > n)
			{
				break;
			}
			System.out.println();
			i++;
		}
		
		System.out.println();
		k = 1;
		i = 1;
		do
		{
			int j = 1;
			do
			{
				if (k <= 3)
				{
					System.out.print(k + " ");
					New = k;
					old = k - 1;
				}
				else
				{
					k = New * old;
					if (k > n)
					{
						break;
					}
					System.out.print(k + " ");
					old = New;
					New = k;
				}
				k++;
				j++;
			} while (j <= i);
			if (k > n)
			{
				break;
			}
			System.out.println();
			i++;
		} while (i <= n);
	}
}