// 1 2 3 6 18 108 1944 ... n

import java.util.*;

class Sequence1
{
	public static void main(String args[])
	{
		Scanner sc = new Scanner(System.in);
		int old = 0, New = 0;
		System.out.print("Enter a number : ");
		int n = sc.nextInt();
		for (int i = 1; i <= n; i++)
		{
			if (i <= 3)
			{
				System.out.print(i + " ");
				New = i;
				old = i - 1;
			}
			else
			{
				i = New * old;
				if (i > n)
				{
					break;
				}
				System.out.print(i + " ");
				old = New;
				New = i;
			}
		}
		System.out.println();
	}
}