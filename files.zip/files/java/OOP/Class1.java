// Example of Constructor without arguments

class Class1a
{
		int a, b;
		Class1a()
		{
			System.out.println("Constructor!");
			a = 10;
			b = 10;
		}
}

class Class1
{
	public static void main(String args[])
	{
		Class1a c1 = new Class1a();
		System.out.println("a = " + c1.a);
		System.out.println("b = " + c1.b);
	}
}