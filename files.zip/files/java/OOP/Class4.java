// Non static member variables and functions

import java.util.*;

class Class4a
{
	int sum(int a, int b)
	{
		return(a + b);
	}
}

class Class4
{
	public static void main(String args[])
	{
		int a, b, s;
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter two numbers : ");
		a = sc.nextInt();
		b = sc.nextInt();
		Class4a c4 = new Class4a();
		s = c4.sum(a, b);
		System.out.println("Sum = " + s);
	}
}