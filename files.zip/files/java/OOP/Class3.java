// Static member variables and static member functions

import java.util.*;

class Class3
{
	static int sum(int a, int b)
	{
		return(a + b);
	}
	
	public static void main(String args[])
	{
		Scanner sc = new Scanner(System.in);
		int a, b;
		System.out.println("Enter two numbers : ");
		a = sc.nextInt();
		b = sc.nextInt();
		int s = sum(a, b);
		System.out.println("Sum = " + s);
	}
}