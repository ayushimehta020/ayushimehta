// Example of Constructor with arguments

class Class2a
{
	int a, b;
	Class2a(int a, int b)
	{
		System.out.println("Constructor!");
		this.a = a;
		this.b = b;
	}
}

class Class2
{
	public static void main(String args[])
	{
		int a = 10, b = 20;
		Class2a c2 = new Class2a(a, b);
		System.out.println("a = " + c2.a);
		System.out.println("b = " + c2.b);
	}
}